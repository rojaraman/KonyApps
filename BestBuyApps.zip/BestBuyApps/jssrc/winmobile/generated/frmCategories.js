//Form JS File
function frmCategories_frmCategories_init_seq0(eventobject, neworientation) {
    functionCatSeqInit.call(this, null, null);
};

function frmCategories_btnSearch_onClick_seq0(eventobject) {
    ClickedItem = "Search"
    kony.print("*******************Search Clicked ***" + ClickedItem)
    if (frmCategories.tbxSearch.text == "") {
        alert("Please enter Valid Keyword !")
    } else {
        frmProduct.show();
    }
};

function frmCategories_segCat_onRowClick_seq0(eventobject, sectionNumber, rowNumber) {
    functionRowClickCat.call(this);
};

function addWidgetsfrmCategories() {
    var tbxSearch = new kony.ui.TextBox2({
        "id": "tbxSearch",
        "isVisible": true,
        "text": null,
        "secureTextEntry": false,
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": "enter keywords ...",
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "skin": "sknSearchTbx",
        "focusSkin": "tbx2Focus"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 43
    }, {
        "autoFilter": false
    });
    var btnSearch = new kony.ui.Button({
        "id": "btnSearch",
        "isVisible": true,
        "text": "Search",
        "skin": "sknBtnSearch",
        "focusSkin": "btnFocus",
        "onClick": frmCategories_btnSearch_onClick_seq0
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [16, 0, 16, 0],
        "padding": [0, 3, 0, 3],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 37
    }, {});
    var hboxSearch = new kony.ui.Box({
        "id": "hboxSearch",
        "isVisible": true,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 11,
        "percent": true,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "vExpand": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});
    hboxSearch.add(
    tbxSearch, btnSearch);
    var lblBreadCrum = new kony.ui.Label({
        "id": "lblBreadCrum",
        "isVisible": true,
        "text": "Home",
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 6
    }, {});
    var segCatbox = new kony.ui.Box({
        "id": "segCatbox",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL
    }, {
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "containerWeight": 53
    }, {});
    var segCat = new kony.ui.SegmentedUI2({
        "id": "segCat",
        "isVisible": true,
        "retainSelection": false,
        "widgetDataMap": {
            "id": "id",
            "lblItems": "lblItems"
        },
        "rowTemplate": segCatbox,
        "widgetSkin": "sknSeg",
        "rowSkin": "seg2Normal",
        "rowFocusSkin": "seg2Focus",
        "sectionHeaderSkin": "seg2Header",
        "separatorRequired": true,
        "separatorThickness": 1,
        "separatorColor": "64646400",
        "showScrollbars": false,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "groupCells": false,
        "screenLevelWidget": false,
        "onRowClick": frmCategories_segCat_onRowClick_seq0,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "viewConfig": {
            "coverflowConfig": {
                "projectionAngle": 60,
                "isCircular": true
            }
        }
    }, {
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "containerHeight": null,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 53
    }, {});
    var lblItems = new kony.ui.Label({
        "id": "lblItems",
        "isVisible": true,
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 11
    }, {});
    segCatbox.add(
    lblItems);
    frmCategories.add(
    hboxSearch, lblBreadCrum, segCat);
};

function frmCategoriesGlobals() {
    var MenuId = [];
    frmCategories = new kony.ui.Form2({
        "id": "frmCategories",
        "title": null,
        "needAppMenu": true,
        "headers": [hboxHeader],
        "enabledForIdleTimeout": false,
        "skin": "sknFrm",
        "init": frmCategories_frmCategories_init_seq0,
        "addWidgets": addWidgetsfrmCategories
    }, {
        "padding": [3, 3, 3, 3],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": true,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {
        "retainScrollPosition": false,
        "maxAppMenuButtons": 4,
        "showMiniAppMenu": false,
        "animateHeaderFooter": false,
        "inTransitionConfig": {
            "inTransition": "Slide",
            "transitionMode": "Parallel",
            "transitionSpeed": "0"
        },
        "outTransitionConfig": {
            "outTransition": "Slide",
            "transitionMode": "Parallel",
            "transitionSpeed": "0"
        },
        "directChildrenIDs": ["hboxSearch", "tbxSearch", "btnSearch", "segCat", "lblBreadCrum"]
    });
};