//Form JS File
function frmCategories_segCat_onRowClick_seq1(status, GetCategories) {
    if (status == 400) {
        if (GetCategories["opstatus"] == 0) {
            if (GetCategories["subCat"].length != 0) {
                /* 
 






















frmCategories.lblBreadCrum.text = frmCategories.lblBreadCrum.text + " -> "+frmCategories["segCat"]["selectedItems"][0]["lblItems"];

























 if(GetCategories != null && GetCategories != undefined && GetCategories["subCat"] != null && GetCategories["subCat"] != undefined ){
var frmCategories_segCat_temp = [] ;
for (var i1 =0 ; i1< GetCategories["subCat"].length; i1++) {
frmCategories_segCat_temp.push( {
 
 "id" : GetCategories["subCat"][i1]["id"]
 ,
 
 
 "lblItems" : GetCategories["subCat"][i1]["lblItems"]
 
} )
}
 frmCategories.segCat.setData(frmCategories_segCat_temp);
 

 }




 */
                /* 
GlobalArray.push( GetCategories["subCat"] )
kony.print(JSON.stringify(GlobalArray));
GvId = frmCategories["segCat"]["selectedItems"][0]["id"]
kony.print("@@@@@@@@@@@@@@@@@"+GvId)

 */
            } else {
                /* 
frmProduct.show();
	
 */
                /* 
kony.print("******************"+ClickedItem+"*****************")

 */
            }
        }
    }
};

function frmCategories_frmCategories_init_seq1(status, GetCategories) {
    if (status == 400) {
        if (GetCategories["opstatus"] == 0) {
            if (GetCategories["subCat"].length != 0) {
                /* 
 






















 if(GetCategories != null && GetCategories != undefined && GetCategories["subCat"] != null && GetCategories["subCat"] != undefined ){
var frmCategories_segCat_temp = [] ;
for (var i1 =0 ; i1< GetCategories["subCat"].length; i1++) {
frmCategories_segCat_temp.push( {
 
 "id" : GetCategories["subCat"][i1]["id"]
 ,
 
 
 "lblItems" : GetCategories["subCat"][i1]["lblItems"]
 
} )
}
 frmCategories.segCat.setData(frmCategories_segCat_temp);
 

 }




 */
                /* 
GlobalArray.push( GetCategories["subCat"] )
kony.print(JSON.stringify(GlobalArray));

 */
            }
        } else {
            /* 
kony.print("@@@@@@@@@@ REFRESHING @@@@@@@@@@")
frmCategories.show()

 */
        }
    }
};

function frmCategories_frmCategories_init_seq0(eventobject, neworientation) {
    /* 
 var GetCategories_inputparam = {};
 GetCategories_inputparam["serviceID"] = "GetCategories";
 
 GetCategories_inputparam["cat"] = "cat00000";

 
GetCategories_inputparam["httpheaders"] = {};

GetCategories_inputparam["httpconfig"] = {};

 



 GetCategories = appmiddlewareinvokerasync (GetCategories_inputparam, frmCategories_frmCategories_init_seq1);
 
 */
    functionCatSeqInit.call(this, null, null);
};

function frmCategories_btnSearch_onClick_seq0(eventobject) {
    ClickedItem = "Search"
    kony.print("*******************Search Clicked ***" + ClickedItem)
    if (frmCategories.tbxSearch.text == "") {
        alert("Please enter Valid Keyword !")
    } else {
        frmProduct.show();
    }
};

function frmCategories_segCat_onRowClick_seq0(eventobject, sectionNumber, rowNumber) {
    /* 
ClickedItem = "segCat"

 */
    /* 
 var GetCategories_inputparam = {};
 GetCategories_inputparam["serviceID"] = "GetCategories";
 
 GetCategories_inputparam["cat"] = frmCategories["segCat"]["selectedItems"][0]["id"];

 
GetCategories_inputparam["httpheaders"] = {};

GetCategories_inputparam["httpconfig"] = {};

 



 GetCategories = appmiddlewareinvokerasync (GetCategories_inputparam, frmCategories_segCat_onRowClick_seq1);
 
 */
    functionRowClickCat.call(this);
};

function addWidgetsfrmCategories() {
    var tbxSearch = new kony.ui.TextBox2({
        "id": "tbxSearch",
        "isVisible": true,
        "text": null,
        "secureTextEntry": false,
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "placeholder": "enter keywords ...",
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "skin": "sknSearchTbx",
        "focusSkin": "tbx2Focus",
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 43
    }, {
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "autoFilter": false,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var btnSearch = new kony.ui.Button({
        "id": "btnSearch",
        "isVisible": true,
        "text": "Search",
        "skin": "sknBtnSearch",
        "focusSkin": "btnFocus",
        "onClick": frmCategories_btnSearch_onClick_seq0
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [16, 0, 16, 0],
        "padding": [0, 3, 0, 3],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 37
    }, {});
    var hboxSearch = new kony.ui.Box({
        "id": "hboxSearch",
        "isVisible": true,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 11,
        "percent": true,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "vExpand": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});
    hboxSearch.add(
    tbxSearch, btnSearch);
    var lblBreadCrum = new kony.ui.Label({
        "id": "lblBreadCrum",
        "isVisible": true,
        "text": "Home",
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 6
    }, {
        "textCopyable": false
    });
    var segCatbox = new kony.ui.Box({
        "id": "segCatbox",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL
    }, {
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "containerWeight": 53
    }, {});
    var segCat = new kony.ui.SegmentedUI2({
        "id": "segCat",
        "isVisible": true,
        "retainSelection": false,
        "widgetDataMap": {
            "id": "id",
            "lblItems": "lblItems"
        },
        "rowTemplate": segCatbox,
        "widgetSkin": "sknSeg",
        "rowSkin": "seg2Normal",
        "rowFocusSkin": "seg2Focus",
        "sectionHeaderSkin": "seg2Header",
        "separatorRequired": true,
        "separatorThickness": 1,
        "separatorColor": "64646400",
        "showScrollbars": false,
        "groupCells": false,
        "screenLevelWidget": false,
        "onRowClick": frmCategories_segCat_onRowClick_seq0,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "viewConfig": {
            "coverflowConfig": {
                "projectionAngle": 60,
                "isCircular": true
            }
        }
    }, {
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "containerHeight": null,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 53
    }, {
        "pressedSkin": "sknSegPressed"
    });
    var lblItems = new kony.ui.Label({
        "id": "lblItems",
        "isVisible": true,
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 11
    }, {
        "textCopyable": false
    });
    segCatbox.add(
    lblItems);
    frmCategories.add(
    hboxSearch, lblBreadCrum, segCat);
};

function frmCategoriesGlobals() {
    var MenuId = [];
    frmCategories = new kony.ui.Form2({
        "id": "frmCategories",
        "title": null,
        "needAppMenu": true,
        "headers": [hboxHeader],
        "enabledForIdleTimeout": false,
        "skin": "sknFrm",
        "init": frmCategories_frmCategories_init_seq0,
        "addWidgets": addWidgetsfrmCategories
    }, {
        "padding": [3, 3, 3, 3],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": true,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {
        "retainScrollPosition": false,
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE,
        "titleBar": true,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "formAnimation": 0
        },
        "outTransitionConfig": {
            "formAnimation": 0
        },
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU
    });
};