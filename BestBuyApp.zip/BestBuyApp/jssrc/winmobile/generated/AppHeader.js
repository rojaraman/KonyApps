//Template File
function AppHeader_btnBack_onClick_seq0(eventobject) {
    BackBtnOnClick.call(this);
};

function initializeAppHeader() {
    hboxHeader = new kony.ui.Box({
        "id": "hboxHeader",
        "isVisible": true,
        "skin": "sknhbox",
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 11,
        "percent": true,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "vExpand": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});

    function addWidgetshboxHeader() {
        var btnBack = new kony.ui.Button({
            "id": "btnBack",
            "isVisible": true,
            "text": null,
            "skin": "sknBtnBack",
            "focusSkin": "sknBackBtnFocus",
            "onClick": AppHeader_btnBack_onClick_seq0
        }, {
            "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
            "vExpand": false,
            "hExpand": true,
            "margin": [1, 1, 1, 1],
            "padding": [0, 3, 0, 3],
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "marginInPixel": true,
            "paddingInPixel": false,
            "containerWeight": 19
        }, {});
        var btnHidden = new kony.ui.Button({
            "id": "btnHidden",
            "isVisible": true,
            "text": null,
            "skin": "skn",
            "focusSkin": "btnFocus"
        }, {
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
            "vExpand": false,
            "hExpand": true,
            "margin": [1, 1, 1, 1],
            "padding": [0, 3, 0, 3],
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "marginInPixel": true,
            "paddingInPixel": false,
            "containerWeight": 22
        }, {});
        var imgLogo = new kony.ui.Image2({
            "id": "imgLogo",
            "isVisible": true,
            "src": "logosm.png",
            "imageWhenFailed": null,
            "imageWhileDownloading": null
        }, {
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
            "margin": [0, 0, 0, 0],
            "padding": [0, 0, 0, 0],
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "referenceWidth": null,
            "referenceHeight": null,
            "marginInPixel": false,
            "paddingInPixel": false,
            "containerWeight": 22
        }, {});
        hboxHeader.add(
        btnBack, btnHidden, imgLogo);
    }
    addWidgetshboxHeader();
};