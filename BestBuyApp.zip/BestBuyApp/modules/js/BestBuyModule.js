var ClickedItem;
var pageno;
var currentform;
var GlobalArray = [];
var GvId = [];
var GvName = [];
//for frmProducts
function functionseq1(status, GetProducts) {
    if (status == 400) {
        if (GetProducts["opstatus"] == 0) {
            if (GetProducts["products"].length != 0) {
                if (GetProducts != null && GetProducts != undefined && GetProducts["products"] != null && GetProducts["products"] != undefined) {
                    var frmProduct_segProd_temp = [];
                    for (var i1 = 0; i1 < GetProducts["products"].length; i1++) {
                    if(GetProducts["products"][i1]["onSale"] == "true")
                    {
                     	sale = "On Sale!!"
                     	saleprice = "On sale Price : $"+GetProducts["products"][i1]["salePrice"]
                     	regPrice = ""
                    }
                    else
                    {
                    	sale = ""
                     	saleprice = ""
                     	regPrice = "Price : $"+GetProducts["products"][i1]["regularPrice"]
                    }
                    
                    if(GetProducts["products"][i1]["customerReviewAverage"] == "")
                    {
                    	review =""
                    }
                    else
                    {
                    	review = "Avg Rev :"+GetProducts["products"][i1]["customerReviewAverage"]
                    }
                                  
                        frmProduct_segProd_temp.push({
                            "onSale": sale,
                            "name": GetProducts["products"][i1]["name"],
                            "salePrice": saleprice,
                            "sku": GetProducts["products"][i1]["sku"],
                            "thumbnailImage": GetProducts["products"][i1]["thumbnailImage"],
                            "customerReviewAverage": review,
                            "regularPrice": regPrice,
                            "productId": GetProducts["products"][i1]["productId"]
                        })
                    }
                    frmProduct.segProd.setData(frmProduct_segProd_temp);
                }
                
                frmProduct.lblCategory.text = "Category : " + frmCategories["segCat"]["selectedItems"][0]["lblItems"];
                frmProduct.Page.text = "Page :" + GetProducts["currentPage"]+" of "+GetProducts["totalPages"];
                frmProduct.lblPgeHidden.text = GetProducts["currentPage"];
                if(frmProduct.lblPgeHidden.text != "1")
                {
                	frmProduct.Prev.setVisibility(true);
                }
                else
                {
                	frmProduct.Prev.setVisibility(false)
                }
                if(GetProducts["totalPages"] == 0)
                {
                	alert("NO PRODUCTS!!!");
                }
            }
        }
    }
};
function functionseq2(status, GetSearch) {
    if (status == 400) {
        if (GetSearch["opstatus"] == 0) {
            if (GetSearch["products"].length != 0) {
                if (GetSearch != null && GetSearch != undefined && GetSearch["products"] != null && GetSearch["products"] != undefined) {
                    var frmProduct_segProd_temp = [];
                    for (var i1 = 0; i1 < GetSearch["products"].length; i1++) {
                    	if(GetSearch["products"][i1]["onSale"] == "true")
                    	{
                    		sale = "On Sale!!!"
                    		saleprice = "On Sale Price : $"+GetSearch["products"][i1]["salePrice"]
                    		regularPrice = ""
                    	}
                    	else
                    	{
                    		sale = ""
                    		saleprice = ""
                    		regPrice = "Price : $"+GetSearch["products"][i1]["regularPrice"]
                    	}
                    	if(GetSearch["products"][i1]["customerReviewAverage"] == "")
                    	{
                    		review = ""
                    	}
                    	else
                    	{
                    		review = "Avg Rev : "+GetSearch["products"][i1]["customerReviewAverage"]
                    	}
                        frmProduct_segProd_temp.push({
                            "onSale": sale,
                            "name": GetSearch["products"][i1]["name"],
                            "salePrice": saleprice,
                            "sku": GetSearch["products"][i1]["sku"],
                            "thumbnailImage": GetSearch["products"][i1]["thumbnailImage"],
                            "customerReviewAverage": review,
                            "regularPrice": regPrice,
                            "productId": GetSearch["products"][i1]["productId"]
                        })
                    }
                    frmProduct.segProd.setData(frmProduct_segProd_temp);
                }
                frmProduct.lblCategory.text = "Result for : " + frmCategories.tbxSearch.text;
                frmProduct.Page.text = "Page : " + GetSearch["currentPage"]+" of "+GetSearch["totalPages"];
                frmProduct.lblPgeHidden.text = GetSearch["currentPage"];
                  if(frmProduct.lblPgeHidden.text != "1")
                {
                	frmProduct.Prev.setVisibility(true);
                }
                else
                {
                	frmProduct.Prev.setVisibility(false)
                }
                if(GetProducts["totalPages"] == 0)
                {
                	alert("NO PRODUCTS!!!");
                }
            }
        }
    }
};
function FuncProduct() {
    if (ClickedItem == "segCat") {
        var GetProducts_inputparam = {};
        GetProducts_inputparam["serviceID"] = "GetProducts";
        GetProducts_inputparam["pId"] = frmCategories["segCat"]["selectedItems"][0]["id"];
        GetProducts_inputparam["page"] = "1";
        GetProducts_inputparam["httpheaders"] = {};
        GetProducts_inputparam["httpconfig"] = {};
        GetProducts = appmiddlewareinvokerasync(GetProducts_inputparam, functionseq1);
    } else {
        var GetSearch_inputparam = {};
        GetSearch_inputparam["serviceID"] = "GetSearch";
        GetSearch_inputparam["search"] = frmCategories.tbxSearch.text;
        GetSearch_inputparam["page"] = "1";
        GetSearch_inputparam["httpheaders"] = {};
        GetSearch_inputparam["httpconfig"] = {};
        GetSearch = appmiddlewareinvokerasync(GetSearch_inputparam, functionseq2);
    }
};
function functionNext() {

    if (ClickedItem == "segCat") {
        pageno = kony.os.toNumber(frmProduct.lblPgeHidden.text)
        pageno = pageno + 1
        kony.print("*************" + pageno + "************")
        var GetProducts_inputparam = {};
        GetProducts_inputparam["serviceID"] = "GetProducts";
        GetProducts_inputparam["pId"] = frmCategories["segCat"]["selectedItems"][0]["id"];
        GetProducts_inputparam["page"] = "" + pageno;
        GetProducts_inputparam["httpheaders"] = {};
        GetProducts_inputparam["httpconfig"] = {};
        GetProducts = appmiddlewareinvokerasync(GetProducts_inputparam, functionseq1);
    } else {
        pageno = kony.os.toNumber(frmProduct.lblPgeHidden.text)
        pageno = pageno + 1
        kony.print("*************" + pageno + "************")
        var GetSearch_inputparam = {};
        GetSearch_inputparam["serviceID"] = "GetSearch";
        GetSearch_inputparam["search"] = frmCategories.tbxSearch.text;
        GetSearch_inputparam["page"] = "" + pageno;
        GetSearch_inputparam["httpheaders"] = {};
        GetSearch_inputparam["httpconfig"] = {};
        GetSearch = appmiddlewareinvokerasync(GetSearch_inputparam, functionseq2);
    }
};
function functionPrev() {
    if (ClickedItem == "segCat") {
        pageno = kony.os.toNumber(frmProduct.lblPgeHidden.text)
        pageno = pageno - 1
        kony.print("*************" + pageno + "************")
        var GetProducts_inputparam = {};
        GetProducts_inputparam["serviceID"] = "GetProducts";
        GetProducts_inputparam["pId"] = frmCategories["segCat"]["selectedItems"][0]["id"];
        GetProducts_inputparam["page"] = "" + pageno;
        GetProducts_inputparam["httpheaders"] = {};
        GetProducts_inputparam["httpconfig"] = {};
        GetProducts = appmiddlewareinvokerasync(GetProducts_inputparam, functionseq1);
    } else {
    	pageno = kony.os.toNumber(frmProduct.lblPgeHidden.text)
        pageno = pageno - 1
        kony.print("*************" + pageno + "************")
        var GetSearch_inputparam = {};
        GetSearch_inputparam["serviceID"] = "GetSearch";
        GetSearch_inputparam["search"] = frmCategories.tbxSearch.text;
        GetSearch_inputparam["page"] = "" + pageno;
        GetSearch_inputparam["httpheaders"] = {};
        GetSearch_inputparam["httpconfig"] = {};
        GetSearch = appmiddlewareinvokerasync(GetSearch_inputparam, functionseq2);
    }
};
//for frmDetails
function functionSeq1Details(status, GetDetail) {
    if (status == 400) {
        if (GetDetail["opstatus"] == 0) {
            if (GetDetail["products"].length != 0) {
                frmDetails.thumbnailImage.src = GetDetail["products"][0]["thumbnailImage"];
                frmDetails.name.text = GetDetail["products"][0]["name"];
                if(GetDetail["products"][0]["onSale"] == "true")
                {
                	frmDetails.regularPrice.text = "";
                	frmDetails.salePrice.text = "On Sale!! Price : $"+GetDetail["products"][0]["salePrice"];
                }
                else
                {
                	frmDetails.regularPrice.text = "Price : $"+GetDetail["products"][0]["regularPrice"];
                	frmDetails.salePrice.text = "";
                }
                
				if(GetDetail["products"][0]["customerReviewAverage"] != "")
				{
					frmDetails.customerReviewAverage.text = "Avg Rev : "+GetDetail["products"][0]["customerReviewAverage"];
				}
				else
				{
					frmDetails.customerReviewAverage.text = "";
				}
				kony.print("*@**@*@**@*@@**@"+GetDetail["products"][0]["Average"]+"*@**@*@**@*@@**@")
				if(GetDetail["products"][0]["Average"] > 0 && GetDetail["products"][0]["Average"] <= 1)
				{
					frmDetails.Average.src = "stars_1.png"
				}
				else if(GetDetail["products"][0]["Average"] > 1 && GetDetail["products"][0]["Average"] <= 2)
				{
					frmDetails.Average.src = "stars_2.png"
				}
				else if(GetDetail["products"][0]["Average"] > 2 && GetDetail["products"][0]["Average"] <= 3)
				{
					frmDetails.Average.src = "stars_3.png"
				}
				else if(GetDetail["products"][0]["Average"] > 3 && GetDetail["products"][0]["Average"] <= 4)
				{
					frmDetails.Average.src = "stars_4.png"
				}
				else if(GetDetail["products"][0]["Average"] > 4 && GetDetail["products"][0]["Average"] <= 5)
				{
					frmDetails.Average.src = "stars_5.png"
				}
				else
				{
						frmDetails.Average.src = ""
				}
				
               
                frmDetails.shortDescription.text = GetDetail["products"][0]["shortDescription"];
            }
            else
            {
            	alert("Product not available")
            }
        }
    }
};
function functionSeq2Details(status, GetRev) {
    if (status == 400) {
        if (GetRev["opstatus"] == 0) {
            if (GetRev["reviews"].length != 0) {
                if (GetRev != null && GetRev != undefined && GetRev["reviews"] != null && GetRev["reviews"] != undefined) {
                    var frmDetails_segRev_temp = [];
                    for (var i1 = 0; i1 < GetRev["reviews"].length; i1++) {
                       reviewername = "Submitted By : "+GetRev["reviews"][i1]["reviewer"]
                       if(GetRev["reviews"][i1]["rating"] > 0 && GetRev["reviews"][i1]["rating"]<=1)
                    	{
                    		ratingstars = "stars_1.png"
                    	}
                       else if(GetRev["reviews"][i1]["rating"] > 1 && GetRev["reviews"][i1]["rating"]<=2)
                    	{
                    		ratingstars = "stars_2.png"
                    	}
                       else if(GetRev["reviews"][i1]["rating"] > 2 && GetRev["reviews"][i1]["rating"]<=3)
                    	{
                    		ratingstars = "stars_3.png"
                    	}
                       else if(GetRev["reviews"][i1]["rating"] > 3 && GetRev["reviews"][i1]["rating"]<=4)
                    	{
                    		ratingstars = "stars_4.png"
                    	}
                       else if(GetRev["reviews"][i1]["rating"] > 4 && GetRev["reviews"][i1]["rating"]<=5)
                    	{
                    		ratingstars = "stars_5.png"
                    	}
                    	else
                    	{
                    	 	ratingstars = ""
                    	}
                    	frmDetails.total.text = "Number of Reviews : "+GetRev["total"];
                        frmDetails_segRev_temp.push({
                            "title": GetRev["reviews"][i1]["title"],
                            "reviewer": reviewername,
                            "rating": ratingstars,
                            "comment": GetRev["reviews"][i1]["comment"]
                        })
                    }
                    frmDetails.segRev.setData(frmDetails_segRev_temp);
                }
            } else {
                frmDetails.total.text = "No Reviews ..";
                frmDetails.segRev.removeAll();
            }
        }
    }
};

function functionDetails() {
    var GetDetail_inputparam = {};
    GetDetail_inputparam["serviceID"] = "GetDetail";
    GetDetail_inputparam["productId"] = frmProduct["segProd"]["selectedItems"][0]["productId"];
    GetDetail_inputparam["httpheaders"] = {};
    GetDetail_inputparam["httpconfig"] = {};
    GetDetail = appmiddlewareinvokerasync(GetDetail_inputparam, functionSeq1Details);
    var GetRev_inputparam = {};
    GetRev_inputparam["serviceID"] = "GetRev";
    GetRev_inputparam["sku"] = frmProduct["segProd"]["selectedItems"][0]["sku"];
    GetRev_inputparam["httpheaders"] = {};
    GetRev_inputparam["httpconfig"] = {};
    GetRev = appmiddlewareinvokerasync(GetRev_inputparam, functionSeq2Details);
};

function BackBtnOnClick()
{
	currentform = kony.application.getCurrentForm();
	kony.print("@@@@@@@@@@@@@@"+currentform["id"]+"@@@@@@@@@@@@@@@")
	if(currentform["id"] == "frmDetails")
	{
		frmProduct.show();
		frmDetails.segRev.removeAll();
		frmDetails.name.text = "";
		frmDetails.regularPrice.text = "";
		frmDetails.salePrice.text = "";
		frmDetails.thumbnailImage.src = "";
		frmDetails.Average.src = "";
		frmDetails.total.text = "";
		frmDetails.shortDescription.text = "";
		frmDetails.customerReviewAverage.text = "";
	}
	else if(currentform["id"] == "frmProduct")
	{
	 	frmCategories.show();
	 	frmProduct.segProd.removeAll();
	 	frmDetails.segRev.removeAll();
	 	frmProduct.lblCategory.text = "";
	 	frmProduct.lblPgeHidden.text = "";
	 	frmProduct.Page.text = "Page : ";
	 	frmDetails.name.text = "";
		frmDetails.regularPrice.text = "";
		frmDetails.salePrice.text = "";
		frmDetails.thumbnailImage.src = "";
		frmDetails.Average.src = "";
		frmDetails.total.text = "";
		frmDetails.shortDescription.text = "";
		frmDetails.customerReviewAverage.text = "";
		frmCategories.tbxSearch.text = "";
	}
	else if(currentform["id"] == "frmCategories")
	{
		kony.print("@@@@@@@ Action @@@@@@");
		Segment = GlobalArray.pop();
		kony.print(JSON.stringify(Segment));
		for(var i=0 ; i<GvId.length ; i++)
		{
			kony.print("@@@@@@@@@@@"+GvId[i])
		}
		pass = GvId.pop();
		passname = GvName.pop();
		kony.print("@%@%%@%%@%@%%@%%@%@"+pass);
		kony.print("@%@%%@%@%%@%@%%@%@@%"+passname);
		var GetCategories_inputparam = {};
    	GetCategories_inputparam["serviceID"] = "GetCategories";
    	GetCategories_inputparam["cat"] = pass;
    	GetCategories_inputparam["httpheaders"] = {};
   		GetCategories_inputparam["httpconfig"] = {};
   	 	GetCategories = appmiddlewareinvokerasync(GetCategories_inputparam, segCatOnRowClick2);
		if(pass == "cat00000")
		{
			hboxHeader.btnBack.setVisibility(false)
		}
		else
		{
			hboxHeader.btnBack.setVisibility(true)
		}
	}
}


//frmCategories
function segCatOnRowClick(status, GetCategories) {
    if (status == 400) {
        if (GetCategories["opstatus"] == 0) {
            if (GetCategories["subCat"].length != 0) {
                frmCategories.lblBreadCrum.text = frmCategories.lblBreadCrum.text + " -> " + frmCategories["segCat"]["selectedItems"][0]["lblItems"];
                GvName.push(frmCategories["segCat"]["selectedItems"][0]["lblItems"]);
                hboxHeader.btnBack.setVisibility(true)
                if (GetCategories != null && GetCategories != undefined && GetCategories["subCat"] != null && GetCategories["subCat"] != undefined) {
                    var frmCategories_segCat_temp = [];
                    for (var i1 = 0; i1 < GetCategories["subCat"].length; i1++) {
                        frmCategories_segCat_temp.push({
                            "id": GetCategories["subCat"][i1]["id"],
                            "lblItems": GetCategories["subCat"][i1]["lblItems"]                            
                        })
                        
						
                    }
                    frmCategories.segCat.setData(frmCategories_segCat_temp);
                    
                }
                GlobalArray.push(GetCategories["subCat"])
                
                kony.print(JSON.stringify(GlobalArray));      
                kony.print("@@@@@@@@@@@@@@@@@" + GvId +"@@@@@@@@@"+ GvName)
            } else {
            	if(frmCategories["segCat"]["selectedItems"][0]["id"] != "")
            	{
                frmProduct.show();
                kony.print("******************" + ClickedItem + "*****************")
                }
                else
                {
                	alert("No More Products...")
                }
            }
        }
    }
};
function functionRowClickCat() {
    ClickedItem = "segCat"
    var GetCategories_inputparam = {};
    GetCategories_inputparam["serviceID"] = "GetCategories";
    GetCategories_inputparam["cat"] = frmCategories["segCat"]["selectedItems"][0]["id"];
    GetCategories_inputparam["httpheaders"] = {};
    GetCategories_inputparam["httpconfig"] = {};
    GetCategories = appmiddlewareinvokerasync(GetCategories_inputparam, segCatOnRowClick);
    GvId.push(GetCategories_inputparam["cat"]);
};
function segCatOnRowClick2(status, GetCategories)
{
	if (status == 400) {
        if (GetCategories["opstatus"] == 0) {
				frmCategories.lblBreadCrum.text = "Home "
                if (GetCategories != null && GetCategories != undefined && GetCategories["subCat"] != null && GetCategories["subCat"] != undefined) {
                    var frmCategories_segCat_temp = [];
                    for (var i1 = 0; i1 < GetCategories["subCat"].length; i1++) {
                        frmCategories_segCat_temp.push({
                            "id": GetCategories["subCat"][i1]["id"],
                            "lblItems": GetCategories["subCat"][i1]["lblItems"]                            
                        })
                    }
                    frmCategories.segCat.setData(frmCategories_segCat_temp);
                }
                GlobalArray.push(GetCategories["subCat"])
                
                kony.print(JSON.stringify(GlobalArray));      
                kony.print("@@@@@@@@@@@@@@@@@" + GvId) 
            }
        }
    
};

//init
function functionInitCat(status, GetCategories) {
    if (status == 400) {
        if (GetCategories["opstatus"] == 0) {
            if (GetCategories["subCat"].length != 0) {
            	frmCategories.lblBreadCrum.text = ""
            	hboxHeader.btnBack.setVisibility(false);
                if (GetCategories != null && GetCategories != undefined && GetCategories["subCat"] != null && GetCategories["subCat"] != undefined) {
                    var frmCategories_segCat_temp = [];
                    for (var i1 = 0; i1 < GetCategories["subCat"].length; i1++) {
                        frmCategories_segCat_temp.push({
                            "id": GetCategories["subCat"][i1]["id"],
                            "lblItems": GetCategories["subCat"][i1]["lblItems"]
                        })
                    }
                    frmCategories.segCat.setData(frmCategories_segCat_temp);
                }
                GlobalArray.push(GetCategories["subCat"])
                kony.print(JSON.stringify(GlobalArray));
            }
        } else {
            kony.print("@@@@@@@@@@ REFRESHING @@@@@@@@@@")
            frmCategories.show()
        }
    }
};

function functionCatSeqInit() {
    var GetCategories_inputparam = {};
    GetCategories_inputparam["serviceID"] = "GetCategories";
    GetCategories_inputparam["cat"] = "cat00000";
    GetCategories_inputparam["httpheaders"] = {};
    GetCategories_inputparam["httpconfig"] = {};
    GetCategories = appmiddlewareinvokerasync(GetCategories_inputparam, functionInitCat);
    GvId.push("cat00000");
};