//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "BestBuyApp",
    appName: "BestBuyApp",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "169.254.80.80",
    serverPort: "8080",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "middleware",
    url: "http://169.254.80.80:8080/middleware/MWServlet",
    secureurl: "http://169.254.80.80:8080/middleware/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    initializeAppHeader();
    frmCategoriesGlobals();
    frmDetailsGlobals();
    frmProductGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true
    })
};

function themeCallBack() {
    kony.application.setApplicationInitializationEvents({
        init: appInit,
        showstartupform: function() {
            frmCategories.show();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
};
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();