//Form JS File
function frmProduct_Next_onClick_seq3(status, GetProducts) {
    /* 
kony.print("*****************service call*************")

 */
};

function frmProduct_frmProduct_preshow_seq10(status, GetSearch) {
    if (status == 400) {
        if (GetSearch["opstatus"] == 0) {
            if (GetSearch["products"].length != 0) {
                /* 
 






















 if(GetSearch != null && GetSearch != undefined && GetSearch["products"] != null && GetSearch["products"] != undefined ){
var frmProduct_segProd_temp = [] ;
for (var i1 =0 ; i1< GetSearch["products"].length; i1++) {
frmProduct_segProd_temp.push( {
 
 "onSale" : GetSearch["products"][i1]["onSale"]
 ,
 
 
 "name" : GetSearch["products"][i1]["name"]
 ,
 
 
 "salePrice" : GetSearch["products"][i1]["salePrice"]
 ,
 
 
 "sku" : GetSearch["products"][i1]["sku"]
 ,
 
 
 "thumbnailImage" : GetSearch["products"][i1]["thumbnailImage"]
 ,
 
 
 "customerReviewAverage" : GetSearch["products"][i1]["customerReviewAverage"]
 ,
 
 
 "regularPrice" : GetSearch["products"][i1]["regularPrice"]
 ,
 
 
 "productId" : GetSearch["products"][i1]["productId"]
 
} )
}
 frmProduct.segProd.setData(frmProduct_segProd_temp);
 

 }
























frmProduct.lblCategory.text = "Result for : "+frmCategories.tbxSearch.text;

























frmProduct.Page.text = "Page : "+ GetSearch["currentPage"];





 */
            }
        }
    }
};

function frmProduct_frmProduct_preshow_seq3(status, GetProducts) {
    if (status == 400) {
        if (GetProducts["opstatus"] == 0) {
            if (GetProducts["products"].length != 0) {
                /* 
 






















 if(GetProducts != null && GetProducts != undefined && GetProducts["products"] != null && GetProducts["products"] != undefined ){
var frmProduct_segProd_temp = [] ;
for (var i1 =0 ; i1< GetProducts["products"].length; i1++) {
frmProduct_segProd_temp.push( {
 
 "onSale" : GetProducts["products"][i1]["onSale"]
 ,
 
 
 "name" : GetProducts["products"][i1]["name"]
 ,
 
 
 "salePrice" : GetProducts["products"][i1]["salePrice"]
 ,
 
 
 "sku" : GetProducts["products"][i1]["sku"]
 ,
 
 
 "thumbnailImage" : GetProducts["products"][i1]["thumbnailImage"]
 ,
 
 
 "customerReviewAverage" : GetProducts["products"][i1]["customerReviewAverage"]
 ,
 
 
 "regularPrice" : GetProducts["products"][i1]["regularPrice"]
 ,
 
 
 "productId" : GetProducts["products"][i1]["productId"]
 
} )
}
 frmProduct.segProd.setData(frmProduct_segProd_temp);
 

 }
























frmProduct.lblCategory.text = "Category : "+frmCategories["segCat"]["selectedItems"][0]["lblItems"];

























frmProduct.Page.text = "Page :"+ GetProducts["currentPage"];





 */
                /* 
frmProduct_frmProduct_preshow_seq3.call(this,null, null);

 */
            }
        }
    }
};

function frmProduct_frmProduct_preshow_seq0(eventobject, neworientation) {
    if (ClickedItem == "segCat") {
        /* 
 var GetProducts_inputparam = {};
 GetProducts_inputparam["serviceID"] = "GetProducts";
 
 GetProducts_inputparam["pId"] = frmCategories["segCat"]["selectedItems"][0]["id"];
GetProducts_inputparam["page"] = "1";

 
GetProducts_inputparam["httpheaders"] = {};

GetProducts_inputparam["httpconfig"] = {};

 



 GetProducts = appmiddlewareinvokerasync (GetProducts_inputparam, frmProduct_frmProduct_preshow_seq3);
 
 */
    } else {
        /* 
 var GetSearch_inputparam = {};
 GetSearch_inputparam["serviceID"] = "GetSearch";
 
 






















GetSearch_inputparam["search"] = frmCategories.tbxSearch.text;


GetSearch_inputparam["page"] = "1";

 
GetSearch_inputparam["httpheaders"] = {};

GetSearch_inputparam["httpconfig"] = {};

 



 GetSearch = appmiddlewareinvokerasync (GetSearch_inputparam, frmProduct_frmProduct_preshow_seq10);
 
 */
    }
    FuncProduct.call(this);
};

function frmProduct_segProd_onRowClick_seq0(eventobject, sectionNumber, rowNumber) {
    frmDetails.show();
};

function frmProduct_btnExit_onClick_seq0(eventobject) {
    kony.application.exit()
};

function frmProduct_Prev_onClick_seq0(eventobject) {
    if (ClickedItem == "segCat") {
        /* 
pageno= kony.os.toNumber(frmProduct.lblPgeHidden.text)
 pageno= pageno-1
 kony.print("*************"+pageno+"************")

 */
        /* 
 var GetProducts_inputparam = {};
 GetProducts_inputparam["serviceID"] = "GetProducts";
 
 GetProducts_inputparam["pId"] = frmCategories["segCat"]["selectedItems"][0]["id"];
GetProducts_inputparam["page"] = ""+pageno;

 
GetProducts_inputparam["httpheaders"] = {};

GetProducts_inputparam["httpconfig"] = {};

 



 GetProducts = appmiddlewareinvokerasync (GetProducts_inputparam, frmProduct_Prev_onClick_seq3);
 
 */
    } else {
        /* 
pageno= kony.os.toNumber(frmProduct.lblPgeHidden.text)
 pageno= pageno-1
 kony.print("*************"+pageno+"************")

 */
        /* 
 var GetSearch_inputparam = {};
 GetSearch_inputparam["serviceID"] = "GetSearch";
 
 






















GetSearch_inputparam["search"] = frmCategories.tbxSearch.text;


GetSearch_inputparam["page"] = ""+pageno;

 
GetSearch_inputparam["httpheaders"] = {};

GetSearch_inputparam["httpconfig"] = {};

 



 GetSearch = appmiddlewareinvokerasync (GetSearch_inputparam, frmProduct_Prev_onClick_seq4);
 
 */
    }
    functionPrev.call(this);
};

function frmProduct_Next_onClick_seq0(eventobject) {
    /* 
 pageno= kony.os.toNumber(frmProduct.lblPgeHidden.text)
 pageno= pageno+1
 kony.print("*************"+pageno+"************")

 */
    if (ClickedItem == "segCat") {
        /* 
 pageno= kony.os.toNumber(frmProduct.lblPgeHidden.text)
 pageno= pageno+1
 kony.print("*************"+pageno+"************")

 */
        /* 
 var GetProducts_inputparam = {};
 GetProducts_inputparam["serviceID"] = "GetProducts";
 
 GetProducts_inputparam["pId"] = frmCategories["segCat"]["selectedItems"][0]["id"];
GetProducts_inputparam["page"] = ""+pageno;

 
GetProducts_inputparam["httpheaders"] = {};

GetProducts_inputparam["httpconfig"] = {};

 



 GetProducts = appmiddlewareinvokerasync (GetProducts_inputparam, frmProduct_Next_onClick_seq3);
 
 */
    } else {
        /* 
 pageno= kony.os.toNumber(frmProduct.lblPgeHidden.text)
 pageno= pageno+1
 kony.print("*************"+pageno+"************")

 */
        /* 
 var GetSearch_inputparam = {};
 GetSearch_inputparam["serviceID"] = "GetSearch";
 
 






















GetSearch_inputparam["search"] = frmCategories.tbxSearch.text;


GetSearch_inputparam["page"] = ""+pageno;

 
GetSearch_inputparam["httpheaders"] = {};

GetSearch_inputparam["httpconfig"] = {};

 



 GetSearch = appmiddlewareinvokerasync (GetSearch_inputparam, frmProduct_Next_onClick_seq4);
 
 */
    }
    functionNext.call(this);
};

function addWidgetsfrmProduct() {
    var lblPgeHidden = new kony.ui.Label({
        "id": "lblPgeHidden",
        "isVisible": false,
        "text": null,
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 4
    }, {
        "textCopyable": false
    });
    var lblCategory = new kony.ui.Label({
        "id": "lblCategory",
        "isVisible": true,
        "text": "Category",
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 6
    }, {
        "textCopyable": false
    });
    var segProdbox = new kony.ui.Box({
        "id": "segProdbox",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL
    }, {
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "containerWeight": 41
    }, {});
    var segProd = new kony.ui.SegmentedUI2({
        "id": "segProd",
        "isVisible": true,
        "retainSelection": false,
        "widgetDataMap": {
            "onSale": "onSale",
            "name": "name",
            "salePrice": "salePrice",
            "sku": "sku",
            "thumbnailImage": "thumbnailImage",
            "customerReviewAverage": "customerReviewAverage",
            "regularPrice": "regularPrice",
            "vboxSegProd": "vboxSegProd",
            "hbox68508216643": "hbox68508216643",
            "productId": "productId"
        },
        "rowTemplate": segProdbox,
        "widgetSkin": "sknSeg",
        "rowSkin": "seg2Normal",
        "rowFocusSkin": "seg2Focus",
        "sectionHeaderSkin": "seg2Header",
        "separatorRequired": true,
        "separatorThickness": 1,
        "separatorColor": "64646400",
        "showScrollbars": false,
        "groupCells": false,
        "screenLevelWidget": false,
        "onRowClick": frmProduct_segProd_onRowClick_seq0,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "viewConfig": {
            "coverflowConfig": {
                "projectionAngle": 60,
                "isCircular": true
            }
        }
    }, {
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "containerHeight": null,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 41
    }, {
        "pressedSkin": "sknSegPressed"
    });
    var onSale = new kony.ui.Label({
        "id": "onSale",
        "isVisible": true,
        "skin": "sknOnSale"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 15
    }, {
        "textCopyable": false
    });
    var thumbnailImage = new kony.ui.Image2({
        "id": "thumbnailImage",
        "isVisible": true,
        "imageWhenFailed": null,
        "imageWhileDownloading": null,
        "src": null
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "referenceWidth": null,
        "referenceHeight": null,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 40
    }, {});
    var name = new kony.ui.Label({
        "id": "name",
        "isVisible": true,
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 19
    }, {
        "textCopyable": false
    });
    var regularPrice = new kony.ui.Label({
        "id": "regularPrice",
        "isVisible": true,
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 19
    }, {
        "textCopyable": false
    });
    var salePrice = new kony.ui.Label({
        "id": "salePrice",
        "isVisible": true,
        "skin": "sknLablOnSalered"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 19
    }, {
        "textCopyable": false
    });
    var customerReviewAverage = new kony.ui.Label({
        "id": "customerReviewAverage",
        "isVisible": true,
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 19
    }, {
        "textCopyable": false
    });
    var sku = new kony.ui.Label({
        "id": "sku",
        "isVisible": false,
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 19
    }, {
        "textCopyable": false
    });
    var vboxSegProd = new kony.ui.Box({
        "id": "vboxSegProd",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL
    }, {
        "containerWeight": 57,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "vExpand": false,
        "hExpand": true,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});
    vboxSegProd.add(
    name, regularPrice, salePrice, customerReviewAverage, sku);
    var hbox68508216643 = new kony.ui.Box({
        "id": "hbox68508216643",
        "isVisible": true,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 79,
        "percent": true,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "vExpand": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});
    hbox68508216643.add(
    thumbnailImage, vboxSegProd);
    segProdbox.add(
    onSale, hbox68508216643);
    var btnExit = new kony.ui.Button({
        "id": "btnExit",
        "isVisible": true,
        "text": "Exit",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmProduct_btnExit_onClick_seq0
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [0, 3, 0, 3],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 6
    }, {});
    var Prev = new kony.ui.Button({
        "id": "Prev",
        "isVisible": true,
        "text": "<< Prev",
        "skin": "sknBtnSearch",
        "focusSkin": "btnFocus",
        "onClick": frmProduct_Prev_onClick_seq0
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [0, 3, 0, 3],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 30
    }, {});
    var Page = new kony.ui.Label({
        "id": "Page",
        "isVisible": true,
        "text": "Page",
        "skin": "sknLbl"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 40
    }, {
        "textCopyable": false
    });
    var Next = new kony.ui.Button({
        "id": "Next",
        "isVisible": true,
        "text": "Next >>",
        "skin": "sknBtnSearch",
        "focusSkin": "btnFocus",
        "onClick": frmProduct_Next_onClick_seq0
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "padding": [0, 3, 0, 3],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 30
    }, {});
    var hboxFooter = new kony.ui.Box({
        "id": "hboxFooter",
        "isVisible": true,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 11,
        "percent": true,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "vExpand": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});
    hboxFooter.add(
    Prev, Page, Next);
    frmProduct.add(
    lblPgeHidden, lblCategory, segProd, btnExit, hboxFooter);
};

function frmProductGlobals() {
    var MenuId = [];
    frmProduct = new kony.ui.Form2({
        "id": "frmProduct",
        "title": null,
        "needAppMenu": true,
        "headers": [hboxHeader],
        "enabledForIdleTimeout": false,
        "skin": "sknFrm",
        "preShow": frmProduct_frmProduct_preshow_seq0,
        "addWidgets": addWidgetsfrmProduct
    }, {
        "padding": [5, 5, 5, 5],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": true,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {
        "retainScrollPosition": false,
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE,
        "titleBar": true,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "formAnimation": 0
        },
        "outTransitionConfig": {
            "formAnimation": 0
        },
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU
    });
};