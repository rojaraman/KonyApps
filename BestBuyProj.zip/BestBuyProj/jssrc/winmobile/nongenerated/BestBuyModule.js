var ClickedItem;

function frmProduct_frmProduct_preshow_seq3(status, GetProducts) {
    if (status == 400) {
        if (GetProducts["opstatus"] == 0) {
            if (GetProducts["products"].length != 0) {
                if (GetProducts != null && GetProducts != undefined && GetProducts["products"] != null && GetProducts["products"] != undefined) {
                    var frmProduct_segProd_temp = [];
                    for (var i1 = 0; i1 < GetProducts["products"].length; i1++) {
                        if (GetProducts["products"][i1]["onSale"] == "true") {
                            sale = "On Sale!!"
                            saleprice = "On sale Price : $" + GetProducts["products"][i1]["salePrice"]
                            regPrice = ""
                        } else {
                            sale = ""
                            saleprice = ""
                            regPrice = "Price : $" + GetProducts["products"][i1]["regularPrice"]
                        }
                        if (GetProducts["products"][i1]["customerReviewAverage"] == "") {
                            review = ""
                        } else {
                            review = "Avg Rev :" + GetProducts["products"][i1]["customerReviewAverage"]
                        }
                        frmProduct_segProd_temp.push({
                            "onSale": sale,
                            "name": GetProducts["products"][i1]["name"],
                            "salePrice": saleprice,
                            "sku": GetProducts["products"][i1]["sku"],
                            "thumbnailImage": GetProducts["products"][i1]["thumbnailImage"],
                            "customerReviewAverage": review,
                            "regularPrice": regPrice,
                            "productId": GetProducts["products"][i1]["productId"]
                        })
                    }
                    frmProduct.segProd.setData(frmProduct_segProd_temp);
                }
                frmProduct.lblCategory.text = "Category : " + frmCategories["segCat"]["selectedItems"][0]["lblItems"];
                frmProduct.Page.text = "Page :" + GetProducts["currentPage"];
            }
        }
    }
};

function frmProduct_frmProduct_preshow_seq10(status, GetSearch) {
    if (status == 400) {
        if (GetSearch["opstatus"] == 0) {
            if (GetSearch["products"].length != 0) {
                if (GetSearch != null && GetSearch != undefined && GetSearch["products"] != null && GetSearch["products"] != undefined) {
                    var frmProduct_segProd_temp = [];
                    for (var i1 = 0; i1 < GetSearch["products"].length; i1++) {
                        frmProduct_segProd_temp.push({
                            "onSale": GetSearch["products"][i1]["onSale"],
                            "name": GetSearch["products"][i1]["name"],
                            "salePrice": GetSearch["products"][i1]["salePrice"],
                            "sku": GetSearch["products"][i1]["sku"],
                            "thumbnailImage": GetSearch["products"][i1]["thumbnailImage"],
                            "customerReviewAverage": GetSearch["products"][i1]["customerReviewAverage"],
                            "regularPrice": GetSearch["products"][i1]["regularPrice"],
                            "productId": GetSearch["products"][i1]["productId"]
                        })
                    }
                    frmProduct.segProd.setData(frmProduct_segProd_temp);
                }
                frmProduct.lblCategory.text = "Result for : " + frmCategories.tbxSearch.text;
                frmProduct.Page.text = "Page : " + GetSearch["currentPage"];
            }
        }
    }
};